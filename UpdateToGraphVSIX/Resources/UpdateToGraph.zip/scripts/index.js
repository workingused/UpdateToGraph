﻿Date.prototype.toUTCString = function () {

    function zeroCompletion(time) {
        return ("00" + time).slice(-2);
    }
    // 2017 - 04 - 15T12: 00:00
    return this.getFullYear() + "-" +
        zeroCompletion(this.getMonth() + 1) + "-" +
        zeroCompletion(this.getDate()) + "T" +
        zeroCompletion(this.getHours()) + ":" +
        zeroCompletion(this.getMinutes()) + ":" +
        zeroCompletion(this.getSeconds())
}

Object.defineProperty(Date, "timeZone", {
    get: function () {
        var hourOffset = parseInt(new Date().getTimezoneOffset() / 60);
        return "Etc/GMT" +
            (hourOffset > 0 ? "+" + hourOffset :
                hourOffset == 0 ? "" :
                    "-" + Math.abs(hourOffset));
    }
})

var graph;

$.graph.prototype.GetUser = function () {
    //https://developer.microsoft.com/en-us/graph/docs/api-reference/v1.0/api/user_get

    return common.Request.call(
        this,
        "https://graph.microsoft.com/v1.0/me",
        {
            request_header: {
                'Authorization': 'Bearer ' + window.sessionStorage.token,
                "Content-Type": "application/json",
                "Prefer": 'outlook.timezone="' + Date.timeZone + '"'
            },
            request_body: {}
        },
        "GET",
        true);
}

function GetMyProfile() {
    return graph.GetUser().then(function (that) {
        var data = that.res;

        var container = $(".header");
        if (data) {
            container.find("label").text(data.displayName || data.userPrincipalName + "/");
            container.find("a").text("switch user");
        } else {
            container.find("label").text();
            container.find("a").text("login");
        }

        return data;
    });
}

function login(relogin) {
    var setting = {
        auth_url: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
        token_url: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
        logout_url: '',         // recommended if available
        client_id: 'e6577e8f-ec5c-4140-ae71-d31424692249',          // required
        other_params: {
            scope: 'offline_access openid User.Read Mail.Read Mail.ReadWrite Mail.Send Calendars.Read Calendars.ReadWrite Contacts.ReadWrite'
        },        // optional params object for scope, state, display...

        response_type: 'token',
        redirect_uri: 'http://localhost:23875'
    }

    graph = new $.graph(setting, relogin)
};


if ((window.sessionStorage.token && window.sessionStorage.authorization) ||
    (window.location.hash && window.location.hash.indexOf("access_token") >= 0)) {
    login(false);
}

window.onload = function () {
    if (!((window.sessionStorage.token && window.sessionStorage.authorization) ||
        (window.location.hash && window.location.hash.indexOf("access_token") >= 0))) {
        login(true)
    }
}